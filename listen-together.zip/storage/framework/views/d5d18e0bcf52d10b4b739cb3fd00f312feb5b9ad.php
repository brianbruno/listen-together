<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">

                        <div class="row">
                            <div class="col-md-8">
                                Dashboard - <?php echo e($track); ?>

                            </div>
                            <div class="col-md-4">
                                <div class="text-right">
                                    <?php if(boolval(Auth::user()->spotify_status)): ?>
                                        <a role="button" class="btn btn-danger btn-sm" href="<?php echo e(route('trocar-status')); ?>">Desativar</a>
                                    <?php else: ?>
                                        <a role="button" class="btn btn-success btn-sm" href="<?php echo e(route('trocar-status')); ?>">Ativar</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">
                        <div>
                            <h3>Buscar música</h3>

                            <form action="<?php echo e(route('buscar-musicas')); ?>" method="get">
                                <?php echo csrf_field(); ?>
                                <div class="input-group mb-3">
                                    <input type="text" name="musica" class="form-control" placeholder="Digite a busca" aria-label="Busca">
                                    <div class="input-group-append">
                                        <button class="btn btn-outline-secondary" type="submit" id="button-addon2">Buscar</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div>
                            <?php if(session('status')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>

                            <table class="table">
                                <thead>
                                <tr>
                                    <th> música</th>
                                    <th> fila</th>
                                    <th> usuário</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $itensFila; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td> <?php echo e($item->name); ?> </td>
                                        <td> <?php echo e($item->fila()->first()->name); ?> </td>
                                        <td> <?php echo e($item->user()->first()->name); ?> </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\brian\Documents\Projetos-GIT\PHP\listen-together\resources\views/home.blade.php ENDPATH**/ ?>